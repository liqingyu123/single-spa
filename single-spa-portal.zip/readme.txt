
webpack
    https://www.runoob.com/w3cnote/webpack-tutorial.html
---安装：npm install webpack
---webpack 是一个前端资源加载/打包工具。它将根据模块的依赖关系进行静态分析，然后将这些模块按照指定的规则生成对应的静态资源。
---webpack 可以将多种静态资源 js、css、less 转换成一个静态文件，减少了页面的请求，Webpack 本身只能处理 JavaScript 模块，如果
    要处理其他类型的文件，就需要使用 loader 进行转换。
---可将一些编译选项放在webpack.config.js配置文件中，以便于统一管理。
---需要在package.json指定对Webpack的相关组件依赖
---插件在 webpack 的配置信息 plugins 选项中指定，用于完成一些 loader 不能完成的工作。
    webpack 自带一些插件，可通过 cnpm 安装其它插件。
---当项目逐渐变大，webpack 的编译时间会变长，可以通过参数让编译的输出内容带有进度和颜色。
    webpack --progress --colors
---可使用 webpack-dev-server开发服务，然后就能启动一个 express 静态资源 web 服务器，且以监听模式自动运行webpack，在浏览器打开
     http://localhost:9000/，可浏览项目中的页面和编译后的资源输出，并且通过一个 socket.io 服务实时监听它们的变化并自动刷新页面。
     portal工程package.json配置的对应启动命令：npm run watch -> webpack-dev-server --port 9000

Babel
    https://segmentfault.com/a/1190000017898866?utm_source=tag-newest
---Babel是一个JS编译器，能让新的JS语法在浏览器正常运行。
    如今ES6/ES7/ES8语法在开发中已非常普及，浏览器对ES6/ES7/ES8这些高级语法支持并不好，因此为了让新一代JS语法在浏览器能正常运行，
    Babel应运而生。例如：JS箭头函数 ()=>console.log("Hello babel"); 经过Babel编译后变为：
    (function(){
         return console.log("Hello babel");
    });
---在webpack中使用babel-loader处理：
    安装：npm install -D babel-loader @babel/core @babel/preset-env webpack
---在 webpack 配置对象中，需要将 babel-loader 添加到 module 列表中，并指定exclude选项排除node_modules目录中文件，这样
    babel-loader就配置好了，这时Babel还不能发挥作用，在项目根目录创建.babelrc文件，内容见portal工程.babelrc文件

https://zhuanlan.zhihu.com/p/78362028